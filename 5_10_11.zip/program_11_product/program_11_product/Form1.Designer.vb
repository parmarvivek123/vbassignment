﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.clear_btn = New System.Windows.Forms.Button()
        Me.delete_btn = New System.Windows.Forms.Button()
        Me.update_btn = New System.Windows.Forms.Button()
        Me.insert_btn = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.sale_price = New System.Windows.Forms.TextBox()
        Me.cost_price = New System.Windows.Forms.TextBox()
        Me.qty = New System.Windows.Forms.TextBox()
        Me.pname = New System.Windows.Forms.TextBox()
        Me.pno = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'clear_btn
        '
        Me.clear_btn.Location = New System.Drawing.Point(422, 140)
        Me.clear_btn.Name = "clear_btn"
        Me.clear_btn.Size = New System.Drawing.Size(75, 23)
        Me.clear_btn.TabIndex = 33
        Me.clear_btn.Text = "CLEAR"
        Me.clear_btn.UseVisualStyleBackColor = True
        '
        'delete_btn
        '
        Me.delete_btn.Location = New System.Drawing.Point(422, 105)
        Me.delete_btn.Name = "delete_btn"
        Me.delete_btn.Size = New System.Drawing.Size(75, 23)
        Me.delete_btn.TabIndex = 32
        Me.delete_btn.Text = "DELETE"
        Me.delete_btn.UseVisualStyleBackColor = True
        '
        'update_btn
        '
        Me.update_btn.Location = New System.Drawing.Point(422, 70)
        Me.update_btn.Name = "update_btn"
        Me.update_btn.Size = New System.Drawing.Size(75, 23)
        Me.update_btn.TabIndex = 31
        Me.update_btn.Text = "UPDATE"
        Me.update_btn.UseVisualStyleBackColor = True
        '
        'insert_btn
        '
        Me.insert_btn.Location = New System.Drawing.Point(422, 34)
        Me.insert_btn.Name = "insert_btn"
        Me.insert_btn.Size = New System.Drawing.Size(75, 23)
        Me.insert_btn.TabIndex = 30
        Me.insert_btn.Text = "INSERT"
        Me.insert_btn.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(2, 193)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(544, 150)
        Me.DataGridView1.TabIndex = 29
        '
        'sale_price
        '
        Me.sale_price.Location = New System.Drawing.Point(263, 68)
        Me.sale_price.Name = "sale_price"
        Me.sale_price.Size = New System.Drawing.Size(100, 20)
        Me.sale_price.TabIndex = 27
        '
        'cost_price
        '
        Me.cost_price.Location = New System.Drawing.Point(263, 35)
        Me.cost_price.Name = "cost_price"
        Me.cost_price.Size = New System.Drawing.Size(100, 20)
        Me.cost_price.TabIndex = 26
        '
        'qty
        '
        Me.qty.Location = New System.Drawing.Point(75, 101)
        Me.qty.Name = "qty"
        Me.qty.Size = New System.Drawing.Size(100, 20)
        Me.qty.TabIndex = 25
        '
        'pname
        '
        Me.pname.Location = New System.Drawing.Point(75, 68)
        Me.pname.Name = "pname"
        Me.pname.Size = New System.Drawing.Size(100, 20)
        Me.pname.TabIndex = 24
        '
        'pno
        '
        Me.pno.Location = New System.Drawing.Point(75, 35)
        Me.pno.Name = "pno"
        Me.pno.Size = New System.Drawing.Size(100, 20)
        Me.pno.TabIndex = 23
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(199, 71)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Sale Price"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Location = New System.Drawing.Point(199, 38)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(55, 13)
        Me.lbl4.TabIndex = 20
        Me.lbl4.Text = "Cost Price"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(16, 104)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(23, 13)
        Me.lbl3.TabIndex = 19
        Me.lbl3.Text = "Qty"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(15, 71)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(42, 13)
        Me.label2.TabIndex = 18
        Me.label2.Text = "PName"
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Location = New System.Drawing.Point(16, 38)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(28, 13)
        Me.label.TabIndex = 17
        Me.label.Text = "PNo"
        '
        'form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(548, 346)
        Me.Controls.Add(Me.clear_btn)
        Me.Controls.Add(Me.delete_btn)
        Me.Controls.Add(Me.update_btn)
        Me.Controls.Add(Me.insert_btn)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.sale_price)
        Me.Controls.Add(Me.cost_price)
        Me.Controls.Add(Me.qty)
        Me.Controls.Add(Me.pname)
        Me.Controls.Add(Me.pno)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label)
        Me.Name = "form1"
        Me.Text = "Product Information"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents clear_btn As System.Windows.Forms.Button
    Friend WithEvents delete_btn As System.Windows.Forms.Button
    Friend WithEvents update_btn As System.Windows.Forms.Button
    Friend WithEvents insert_btn As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents sale_price As System.Windows.Forms.TextBox
    Friend WithEvents cost_price As System.Windows.Forms.TextBox
    Friend WithEvents qty As System.Windows.Forms.TextBox
    Friend WithEvents pname As System.Windows.Forms.TextBox
    Friend WithEvents pno As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label As System.Windows.Forms.Label

End Class
