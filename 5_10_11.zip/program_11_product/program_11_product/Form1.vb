﻿Imports System.Data.SqlClient
Public Class form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand


    Private Sub form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\Sem-4\.Net\net practical assignment\program_11_product\program_11_product\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        display()
    End Sub

    Sub display()
        Try
            cmd.CommandText = "select * from tblproduct"
            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub insert_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles insert_btn.Click
        If pno.Text = "" Or pname.Text = "" Or qty.Text = "" Or cost_price.Text = "" Or sale_price.Text = "" Then
            MsgBox("please enter the required fields.")
        Else
            Try
                cmd.CommandText = "insert into tblproduct values(" & pno.Text & ",'" & pname.Text & "','" & qty.Text & "','" & cost_price.Text & "','" & sale_price.Text & "')"
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Inserted Successfully", MsgBoxStyle.Information, "Info")
                clear_text()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
        display()
    End Sub

    Private Sub update_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles update_btn.Click
        If pno.Text = "" Then
            MsgBox("please enter the PNo.")
        Else
            Try
                cmd.CommandText = "update tblproduct set PName='" & pname.Text & "',Qty='" & qty.Text & "',Cost_Price='" & cost_price.Text & "',Sale_Price='" & sale_price.Text & "' where PNo=" & pno.Text & ""
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Updated Successfully", MsgBoxStyle.Information, "Info")
                clear_text()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            display()
        End If
    End Sub

    Private Sub delete_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delete_btn.Click
        If pno.Text = "" Then
            MsgBox("please enter the PNo.")
        Else
            Try
                cmd.CommandText = "delete from tblproduct where PNo=" & pno.Text & ""
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Deleted Successfully", MsgBoxStyle.Information, "Info")
                clear_text()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            display()
        End If
    End Sub

    Private Sub clear_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clear_btn.Click
        Dim result As DialogResult = MessageBox.Show("Do you want to clear all Textboxes?", "Info", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            clear_text()
        End If

    End Sub
    Sub clear_text()
        pno.Clear()
        pname.Clear()
        qty.Clear()
        cost_price.Clear()
        sale_price.Clear()
    End Sub
End Class
