﻿Public Class Form1


    Private Sub submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles submit.Click
        'to print first and last name
        Dim first, last As String
        first = fname.Text
        last = lname.Text
        ListBox1.Items.Add("Name : " + first + " " + last)
        ListBox1.Items.Add(vbNewLine)

        'to print hobbies
        Dim checkboxes As CheckBox() = {CheckBox1, CheckBox2, CheckBox3, CheckBox4}
        Dim cb1 = CheckBox1.Text, cb2 = CheckBox2.Text, cb3 = CheckBox3.Text, cb4 = CheckBox4.Text
        Dim cbvalues As String() = {cb1, cb2, cb3, cb4}

        ListBox1.Items.Add("Hobbies : ")

        For i As Integer = 0 To checkboxes.Length - 1
            If checkboxes(i).Checked Then
                ListBox1.Items.Add(cbvalues(i))
            End If
        Next
        ListBox1.Items.Add(vbNewLine)

        'to print date of birth
        Dim day1, month1, year1 As String
        day1 = day.SelectedItem
        month1 = month.SelectedItem
        year1 = year.SelectedItem
        ListBox1.Items.Add("Date of Birth : " + vbNewLine + day1 + ", " + month1 + ", " + year1)
    End Sub

    Private Sub exit_bt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exit_bt.Click
        Dim result As DialogResult = MessageBox.Show("Do you want to EXIT?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            Me.Close()
        End If

    End Sub

    Private Sub clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clear.Click
        Dim result As DialogResult = MessageBox.Show("Do you want to CLEAR?", "Clear", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            fname.Clear()
            lname.Clear()
            CheckBox1.Checked = False
            CheckBox2.Checked = False
            CheckBox3.Checked = False
            CheckBox4.Checked = False
            ListBox1.Items.Clear()
        End If
    End Sub

    Private Sub ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ok.Click
        MsgBox("Your Datails Submitted Successfully", MsgBoxStyle.Information, "Info")
    End Sub
End Class
