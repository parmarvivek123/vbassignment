﻿Imports System.Data.SqlClient
Public Class form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand


    Private Sub form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=D:\Sem-4\.Net\net practical assignment\project_10_emp\project_10_emp\Database1.mdf;Integrated Security=True;User Instance=True"
            cmd.Connection = con
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        display()
    End Sub

    Sub display()
        Try
            cmd.CommandText = "select * from emp"
            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub insert_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles insert_btn.Click
        If eid.Text = "" Or ename.Text = "" Or city.Text = "" Or doj.Text = "" Or dept.Text = "" Or salary.Text = "" Then
            MsgBox("please enter the required fields.")
        Else
            Try
                cmd.CommandText = "insert into emp values(" & eid.Text & ",'" & ename.Text & "','" & city.Text & "','" & doj.Text & "','" & dept.Text & "'," & salary.Text & ")"
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Inserted Successfully", MsgBoxStyle.Information, "Info")
                clear_text()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
        display()
    End Sub

    Private Sub update_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles update_btn.Click
        If eid.Text = "" Then
            MsgBox("please enter the EmpNo.")
        Else
            Try
                cmd.CommandText = "update emp set EmpName='" & ename.Text & "',City='" & city.Text & "',DOJ='" & doj.Text & "',Department='" & dept.Text & "',Salary=" & salary.Text & " where EmpNo=" & eid.Text & ""
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Updated Successfully", MsgBoxStyle.Information, "Info")
                clear_text()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            display()
        End If
    End Sub

    Private Sub delete_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delete_btn.Click
        If eid.Text = "" Then
            MsgBox("please enter the EmpNo.")
        Else
            Try
                cmd.CommandText = "delete from emp where EmpNo=" & eid.Text & ""
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("Deleted Successfully", MsgBoxStyle.Information, "Info")
                clear_text()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            display()
        End If
    End Sub

    Private Sub clear_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clear_btn.Click
        Dim result As DialogResult = MessageBox.Show("Do you want to clear all Textboxes?", "Info", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            clear_text()
        End If
    End Sub
    Sub clear_text()
        eid.Clear()
        ename.Clear()
        city.Clear()
        salary.Clear()
        doj.Clear()
        dept.Clear()
    End Sub
End Class